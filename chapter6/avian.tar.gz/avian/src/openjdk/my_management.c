#define JNI_OnLoad management_JNI_OnLoad
#include "management.c"
