package avian.testing.annotations;

public enum Color {
  Red, Yellow, Blue
}