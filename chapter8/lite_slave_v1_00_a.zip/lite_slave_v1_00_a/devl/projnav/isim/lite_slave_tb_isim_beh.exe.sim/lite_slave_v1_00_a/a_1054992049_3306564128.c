/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/works/zedboard/gen_ips/gen_ips.srcs/sources_1/edk/system/pcores/lite_slave_v1_00_a/hdl/vhdl/lite_slave.vhd";



static void lite_slave_v1_00_a_a_1054992049_3306564128_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(322, ng0);

LAB3:    t1 = (t0 + 6472U);
    t2 = *((char **)t1);
    t1 = (t0 + 12856);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 32U);
    xsi_driver_first_trans_fast(t1);

LAB2:    t7 = (t0 + 12696);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void lite_slave_v1_00_a_a_1054992049_3306564128_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(323, ng0);

LAB3:    t1 = (t0 + 6792U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 12920);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:    t8 = (t0 + 12712);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void lite_slave_v1_00_a_a_1054992049_3306564128_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(324, ng0);

LAB3:    t1 = (t0 + 6632U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 12984);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:    t8 = (t0 + 12728);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void lite_slave_v1_00_a_a_1054992049_3306564128_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(325, ng0);

LAB3:    t1 = (t0 + 6952U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 13048);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:    t8 = (t0 + 12744);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void lite_slave_v1_00_a_a_1054992049_3306564128_p_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(327, ng0);

LAB3:    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t1 = (t0 + 9408U);
    t3 = *((char **)t1);
    t4 = *((int *)t3);
    t5 = (t4 - 1);
    t6 = (1 - t5);
    t7 = (t6 * 1U);
    t8 = (0 + t7);
    t1 = (t2 + t8);
    t9 = (t0 + 13112);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 2U);
    xsi_driver_first_trans_fast(t9);

LAB2:    t14 = (t0 + 12760);
    *((int *)t14) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void lite_slave_v1_00_a_a_1054992049_3306564128_p_5(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(328, ng0);

LAB3:    t1 = (t0 + 5192U);
    t2 = *((char **)t1);
    t1 = (t0 + 9408U);
    t3 = *((char **)t1);
    t4 = *((int *)t3);
    t5 = (t4 - 1);
    t6 = (1 - t5);
    t7 = (t6 * 1U);
    t8 = (0 + t7);
    t1 = (t2 + t8);
    t9 = (t0 + 13176);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 2U);
    xsi_driver_first_trans_fast(t9);

LAB2:    t14 = (t0 + 12776);
    *((int *)t14) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void lite_slave_v1_00_a_a_1054992049_3306564128_init()
{
	static char *pe[] = {(void *)lite_slave_v1_00_a_a_1054992049_3306564128_p_0,(void *)lite_slave_v1_00_a_a_1054992049_3306564128_p_1,(void *)lite_slave_v1_00_a_a_1054992049_3306564128_p_2,(void *)lite_slave_v1_00_a_a_1054992049_3306564128_p_3,(void *)lite_slave_v1_00_a_a_1054992049_3306564128_p_4,(void *)lite_slave_v1_00_a_a_1054992049_3306564128_p_5};
	xsi_register_didat("lite_slave_v1_00_a_a_1054992049_3306564128", "isim/lite_slave_tb_isim_beh.exe.sim/lite_slave_v1_00_a/a_1054992049_3306564128.didat");
	xsi_register_executes(pe);
}
