/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void axi_lite_ipif_v1_01_a_a_2994498641_3306564128_init()
{
	xsi_register_didat("axi_lite_ipif_v1_01_a_a_2994498641_3306564128", "isim/lite_slave_tb_isim_beh.exe.sim/axi_lite_ipif_v1_01_a/a_2994498641_3306564128.didat");
}
