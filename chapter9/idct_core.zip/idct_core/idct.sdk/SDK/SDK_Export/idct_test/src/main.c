/*
 * main.c
 *
 *  Created on: 2013/02/11
 *      Author: kataoka
 */

#include <stdio.h>
#include "platform.h"
#include "xparameters.h"
#include "xparameters_ps.h"
#include "xil_types.h"
#include "xil_printf.h"
#include "xil_io.h"
#include "xtime_l.h"
#include "idct_ip.h"

#include "common.h"
extern void dct_init();                     //for software idct
extern void idct2(const mat8 *in, mat8 *out);//software idct function


static const u8 __attribute__((aligned (128))) in_buf[IN_BUF_SIZE] = {
#if 1
		0xf7, 0xff, 0x04, 0x00, 0x00, 0x00, 0xe1, 0xff,
		0xda, 0xff, 0xa2, 0xff, 0x1e, 0x00, 0xa2, 0x00,

		0x0b, 0x00, 0xfe, 0xff, 0xf5, 0xff, 0x11, 0x00, 
		0xad, 0xff, 0xc4, 0xff, 0x6c, 0x00, 0x28, 0x00,

		0x07, 0x00, 0x0c, 0x00, 0x0c, 0x00, 0xfb, 0xff, 
		0xfb, 0xff, 0x0c, 0x00, 0x0a, 0x00, 0x14, 0x00,

		0xf0, 0xff, 0x06, 0x00, 0x00, 0x00, 0xf4, 0xff, 
		0xea, 0xff, 0xd5, 0xff, 0x20, 0x00, 0x48, 0x00,

		0x15, 0x00, 0xee, 0xff, 0x1c, 0x00, 0x0e, 0x00, 
		0xf3, 0xff, 0xe1, 0xff, 0x1b, 0x00, 0x1e, 0x00,

		0x00, 0x00, 0xf4, 0xff, 0x0c, 0x00, 0xfb, 0xff, 
		0x0f, 0x00, 0x06, 0x00, 0xf1, 0xff, 0x0c, 0x00,

		0x05, 0x00, 0x07, 0x00, 0x08, 0x00, 0x0b, 0x00, 
		0xff, 0xff, 0xfd, 0xff, 0x12, 0x00, 0xed, 0xff,

		0x0a, 0x00, 0x0c, 0x00, 0x02, 0x00, 0xfa, 0xff, 
		0x03, 0x00, 0x07, 0x00, 0xff, 0xff, 0xf5, 0xff
#else
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0x01,

		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,

		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,

		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,

		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
#endif
};
static u8 __attribute__((aligned (128))) out_buf[OUT_BUF_SIZE];


void DCT_TEST_MasterRecvBytes(u32 BaseAddress, u32 SrcAddress, int Size)
{
	int LsbSize;
	int MsbSize;
	LsbSize = (u16)Size;
	MsbSize = (u8)(Size >> 16);

	Xil_Out8(BaseAddress+MST_CNTL_REG_OFFSET, MST_BRRD);
	Xil_Out32(BaseAddress+MST_ADDR_REG_OFFSET, SrcAddress);
	Xil_Out16(BaseAddress+LSB_MST_LEN_REG_OFFSET, LsbSize);
	Xil_Out8(BaseAddress+MSB_MST_LEN_REG_OFFSET, MsbSize);
	Xil_Out8(BaseAddress+MST_GO_PORT_OFFSET, MST_START);
}

void DCT_TEST_MasterSendBytes(u32 BaseAddress, u32 DstAddress, int Size)
{
	int LsbSize;
	int MsbSize;
	LsbSize = (u16)Size;
	MsbSize = (u8)(Size >> 16);
	Xil_Out8(BaseAddress+MST_CNTL_REG_OFFSET, MST_BRWR);
	Xil_Out32(BaseAddress+MST_ADDR_REG_OFFSET, DstAddress);
	Xil_Out16(BaseAddress+LSB_MST_LEN_REG_OFFSET, LsbSize);
	Xil_Out8(BaseAddress+MSB_MST_LEN_REG_OFFSET, MsbSize);
	Xil_Out8(BaseAddress+MST_GO_PORT_OFFSET, MST_START);
}

void idct_test()
{
	const u32 baseaddr = XPAR_IDCT_0_BASEADDR;
	volatile const u8 *in = in_buf;
	volatile u8 *out = out_buf;
	int i,j;

    DCT_TEST_MasterRecvBytes(baseaddr, (u32)in, IN_BUF_SIZE);
    while (!IS_TRANSFER_DONE(baseaddr)) {}

    while (!IS_DCT_DONE(baseaddr)) {}

    DCT_TEST_MasterSendBytes(baseaddr, (u32)out, OUT_BUF_SIZE);
    while (!IS_TRANSFER_DONE(baseaddr)) {}
/*
    for (i = 0; i < 8; i++) {
    	if (!(out[i*2] == 0x3f && out[i*2+1] == 0x00)) {
    		xil_printf("FAIL!!!!\n\r");
    		return;
    	}
    }
    */
}

static u8 test_buf[IN_BUF_SIZE] = {0};

void idct_test_single(int data_type)
{
	int i, j;
	const u32 baseaddr = XPAR_IDCT_0_BASEADDR;

	volatile const u8 *in = test_buf;//in_buf;
	volatile u8 *out = out_buf;

	if (data_type == 0) {
		memset(test_buf, 0, IN_BUF_SIZE);
		test_buf[15] = 0x01;
		test_buf[14] = 0xFF;
	} else if (data_type == 1) {
		memset(test_buf, 0, IN_BUF_SIZE);
		test_buf[15] = 0xFC;
		test_buf[14] = 0x00;
	} else {
		memcpy(test_buf, in_buf, IN_BUF_SIZE);
	}

    for (i = 0; i < OUT_BUF_SIZE; i++ ) {
    	out_buf[i] = 0xFF;
    }

#if 1
    xil_printf("in_buf \n\r");
    for (i = 0; i < IN_BUF_SIZE; i+=16 ){
    	for (j = 15; j >= 0; --j) {
    		xil_printf("%02x", in[i + j]);
    	}
   		xil_printf("\n\r");
    }
#endif

    DCT_TEST_MasterRecvBytes(baseaddr, (u32)in, IN_BUF_SIZE);
    while (!IS_TRANSFER_DONE(baseaddr)) {xil_printf("wait for recv\n\r");}

    while (!IS_DCT_DONE(baseaddr)) {xil_printf("wait for done\n\r");}

#if 0
    u32 reg1;
    WRITE_REG(XPAR_IDCT_0_BASEADDR, SLV_REG0_OFFSET, 0);
    reg1 = READ_REG(XPAR_IDCT_0_BASEADDR, SLV_REG1_OFFSET);
    xil_printf("out_buf %08x\n\r", reg1);
    WRITE_REG(XPAR_IDCT_0_BASEADDR, SLV_REG0_OFFSET, 1);
    reg1 = READ_REG(XPAR_IDCT_0_BASEADDR, SLV_REG1_OFFSET);
    xil_printf("out_buf %08x\n\r", reg1);
    WRITE_REG(XPAR_IDCT_0_BASEADDR, SLV_REG0_OFFSET, 2);
    reg1 = READ_REG(XPAR_IDCT_0_BASEADDR, SLV_REG1_OFFSET);
    xil_printf("out_buf %08x\n\r", reg1);
    WRITE_REG(XPAR_IDCT_0_BASEADDR, SLV_REG0_OFFSET, 3);
    reg1 = READ_REG(XPAR_IDCT_0_BASEADDR, SLV_REG1_OFFSET);
    xil_printf("out_buf %08x\n\r", reg1);
#endif

    DCT_TEST_MasterSendBytes(baseaddr, (u32)out, OUT_BUF_SIZE);
    while (!IS_TRANSFER_DONE(baseaddr)) {xil_printf("wait for send\n\r");}

#if 1

    xil_printf("out_buf \n\r");
    for (i = 0; i < OUT_BUF_SIZE; i+=16 ){
    	for (j = 15; j >= 0; --j) {
    		xil_printf("%02x", out[i + j]);
    	}
    	xil_printf("\n\r");
    }
#endif
}

void idct_sw_test()
{
	const imat8 in_data[] = {
		{162, 30, -94, -38, -31, 0, 4, -9},
		{40, 108, -60, -83, 17, -11, -2, 11},
		{20, 10, 12, -5, -5, 12, 12, 7},
		{72, 32, -43, -22, -12, 0, 6, -16},
		{30, 27, -31, -13, 14, 28, -18, 21},
		{12, -15, 6, 15, -5, 12, -12, 0},
		{-19, 18, -3, -1, 11, 8, 7, 5},
		{-11, -1, 7, 3, -6, 2, 12, 10}
	};
	imat8 out_data;
	idct(&in_data, &out_data);
	dumpi(&out_data);
}

void user_init()
{
	u32 flags = Xil_In32(XPS_SCU_PERIPH_BASE);
	xil_printf("XPS_SCU_PERIPH_BASE %08x\n\r", flags);

	//Xil_Out32(XPS_SCU_PERIPH_BASE, flags | 1);
}


#define MCU_COUNT ((1920/8)*(1080/8)*3)

void ps_vs_pl()
{
	int i;
	XTime start, end;
	const u32 *s = (u32*)&start;
	const u32 *e = (u32*)&end;

	//-----------------------------
	xil_printf("Software\n\r");
	XTime_GetTime(&start);
	mat8 in, out;
	for (i = 0; i < MCU_COUNT; i++) {
		idct(&in, &out);
	}
	XTime_GetTime(&end);
	
	xil_printf("elapsed: %d %d\n\r", e[1]-s[1], e[0]-s[0]);

	//memset(in_buf, 0, IN_BUF_SIZE);
	//in_buf[15] = 0x01;
	//in_buf[14] = 0xFF;

	xil_printf("\n\r");
	xil_printf("Hardware\n\r");
	XTime_GetTime(&start);
    for (i = 0; i < MCU_COUNT; i++) {
		idct_test();
	}
	XTime_GetTime(&end);

	xil_printf("elapsed: %d %d\n\r", e[1]-s[1], e[0]-s[0]);
}


int main()
{
	init_platform();
	user_init();
	idct_init();

	//idct_sw_test();
	//idct_test_single(0);
	//idct_test_single(1);
	//idct_test_single(2);
	ps_vs_pl();

	cleanup_platform();

    return 0;
}

