#ifndef IDCT_DRIVER_H
#define IDCT_DRIVER_H

#define IN_DATA_BYTES (2)
#define IN_LINE_BYTES (IN_DATA_BYTES*8)
#define IN_NUM_LINES (8)
#define IN_BUF_SIZE (IN_NUM_LINES * IN_LINE_BYTES)
#define OUT_DATA_BYTES (2)
#define OUT_LINE_BYTES (OUT_DATA_BYTES*8)
#define OUT_NUM_LINES (8)
#define OUT_BUF_SIZE (OUT_NUM_LINES * OUT_LINE_BYTES)


#define WRITE_REG(BaseAddress, RegOffset, Data) \
 	Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))

#define READ_REG(BaseAddress, RegOffset) \
 	Xil_In32((BaseAddress) + (RegOffset))


#define IS_TRANSFER_DONE(BaseAddress) \
 	((((u32) Xil_In8((BaseAddress)+(MST_STAT_REG_OFFSET))) & MST_DONE_MASK) == MST_DONE_MASK)

#define IS_DCT_DONE(BaseAddress) \
 	((((u32) Xil_In8((BaseAddress)+(MST_STAT_REG_OFFSET))) & MST_DCT_DONE_MASK) == MST_DCT_DONE_MASK)

/**
 * User Logic Slave Space Offsets
 * -- SLV_REG0 : user logic slave module register 0
 * -- SLV_REG1 : user logic slave module register 1
 */
#define SLV_SPACE_OFFSET (0x00)
#define SLV_REG0_OFFSET (SLV_SPACE_OFFSET + 0x00)
#define SLV_REG1_OFFSET (SLV_SPACE_OFFSET + 0x04)
#define SLV_REG2_OFFSET (SLV_SPACE_OFFSET + 0x08)
#define SLV_REG3_OFFSET (SLV_SPACE_OFFSET + 0x0C)

/**
 * User Logic Master Space Offsets
 * -- MST_CNTL_REG : user logic master module control register
 * -- MST_STAT_REG : user logic master module status register
 * -- MST_ADDR_REG : user logic master module address register
 * -- MST_BE_REG   : user logic master module byte enable register
 * -- MST_LEN_REG  : user logic master module length (data transfer in bytes) register
 * -- MST_GO_PORT  : user logic master module go bit (to start master operation)
 */
#define USER_MST_SPACE_OFFSET (0x100)
#define MST_CNTL_REG_OFFSET (USER_MST_SPACE_OFFSET + 0x00)
#define MST_STAT_REG_OFFSET (USER_MST_SPACE_OFFSET + 0x01)
#define MST_ADDR_REG_OFFSET (USER_MST_SPACE_OFFSET + 0x04)
#define MST_BE_REG_OFFSET (USER_MST_SPACE_OFFSET + 0x08)
#define LSB_MST_LEN_REG_OFFSET (USER_MST_SPACE_OFFSET + 0x0C)
#define MSB_MST_LEN_REG_OFFSET (USER_MST_SPACE_OFFSET + 0x0E)
#define MST_GO_PORT_OFFSET (USER_MST_SPACE_OFFSET + 0x0F)


/**
 * User Logic Master Module Masks
 * -- MST_RD_MASK   : user logic master read request control
 * -- MST_WR_MASK   : user logic master write request control
 * -- MST_BL_MASK   : user logic master bus lock control
 * -- MST_BRST_MASK : user logic master burst assertion control
 * -- MST_DONE_MASK : user logic master transfer done status
 * -- MST_BSY_MASK  : user logic master busy status
 * -- MST_BRRD      : user logic master burst read request
 * -- MST_BRWR      : user logic master burst write request
 * -- MST_SGRD      : user logic master single read request
 * -- MST_SGWR      : user logic master single write request
 * -- MST_START     : user logic master to start transfer
 */
#define MST_RD_MASK (0x00000001UL)
#define MST_WR_MASK (0x00000002UL)
#define MST_BL_MASK (0x00000004UL)
#define MST_BRST_MASK (0x00000008UL)
#define MST_DONE_MASK (0x01)
#define MST_BSY_MASK (0x02)
#define MST_ERROR_MASK (0x04)
#define MST_TIMEOUT_MASK (0x08)
#define MST_DCT_DONE_MASK (0x10)
#define MST_BRRD (0x09)
#define MST_BRWR (0x0A)
#define MST_SGRD (0x01)
#define MST_SGWR (0x02)
#define MST_START (0x0A)

#endif
