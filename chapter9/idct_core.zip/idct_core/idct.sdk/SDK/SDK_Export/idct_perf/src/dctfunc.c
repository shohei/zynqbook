#include "common.h"
#include "xil_printf.h"
#include <math.h>

double C0;
double C1;
double C2;
double C3;
double C4;
double C5;
double C6;
double C7;

void calc_coeff();
void idct_sub1(const mat8 *in, mat8 *out);
void idct_sub2(const vec8 *x, vec8 *y);

void idct_init()
{
	calc_coeff();
}

void calc_coeff()
{
    const double sqrt_2_8 = 0.5;

    C0 = 1/sqrt(8);
    C1 = sqrt_2_8 * cos(1*M_PI/16.0);
    C2 = sqrt_2_8 * cos(2*M_PI/16.0);
    C3 = sqrt_2_8 * cos(3*M_PI/16.0);
    C4 = sqrt_2_8 * cos(4*M_PI/16.0);
    C5 = sqrt_2_8 * cos(5*M_PI/16.0);
    C6 = sqrt_2_8 * cos(6*M_PI/16.0);
    C7 = sqrt_2_8 * cos(7*M_PI/16.0);
}

void idct(const mat8 *in, mat8 *out)
{
    mat8 tmp;
    idct_sub1(in, &tmp);
    idct_sub1(&tmp, out);
}

void idct_sub1(const mat8 *in, mat8 *out)
{
	int i, j;
    for (i = 0; i < 8; ++i) {
        const vec8 *vec = &((*in)[i]);
        vec8 outvec;
        idct_sub2(vec, &outvec);

        //copy with transpose
        for (j = 0; j < 8; ++j) {
            (*out)[j][i] = outvec[j];
        }
    }
}

void idct_sub2(const vec8 *x, vec8 *y)
{
    double a00, a11, a22, a33, a44, a55, a66, a77,
        a31, a62, a73, a15, a26, a57,
        a51, a13, a75, a37,
        a71, a53, a35, a17;
    a00 = C0 * (*x)[0];
    a11 = C1 * (*x)[1];
    a22 = C2 * (*x)[2];
    a33 = C3 * (*x)[3];
    a44 = C4 * (*x)[4];
    a55 = C5 * (*x)[5];
    a66 = C6 * (*x)[6];
    a77 = C7 * (*x)[7];
    a31 = C3 * (*x)[1];
    a62 = C6 * (*x)[2];
    a73 = C7 * (*x)[3];
    a15 = C1 * (*x)[5];
    a26 = C2 * (*x)[6];
    a57 = C5 * (*x)[7];
    a51 = C5 * (*x)[1];
    a13 = C1 * (*x)[3];
    a75 = C7 * (*x)[5];
    a37 = C3 * (*x)[7];
    a71 = C7 * (*x)[1];
    a53 = C5 * (*x)[3];
    a35 = C3 * (*x)[5];
    a17 = C1 * (*x)[7];

    double b00, b10, b20, b30, b40, b50, b60, b70,
        b11, b21, b31, b51, b61, b71,
        b12, b22, b32, b52, b62, b72,
        b13, b23, b33, b53, b63, b73;
    b00 =  a00;
    b10 =  a11;
    b20 =  a22;
    b30 =  a33;
    b40 =  a44;
    b50 =  a55;
    b60 =  a66;
    b70 =  a77;

    b11 =  a31;
    b21 =  a62;
    b31 = -a73;
    b51 = -a15;
    b61 = -a26;
    b71 = -a57;

    b12 =  a51;
    b22 = -a62;
    b32 = -a13;
    b52 =  a75;
    b62 =  a26;
    b72 =  a37;

    b13 =  a71;
    b23 = -a22;
    b33 = -a53;
    b53 =  a35;
    b63 = -a66;
    b73 = -a17;

    double c04p, c04m,
        even0, even1, even2, even3,
        odd0, odd1, odd2, odd3;
    c04p = b00 + b40;
    c04m = b00 - b40;
    even0 = c04p + b20 + b60;
    even1 = c04m + b21 + b61;
    even2 = c04m + b22 + b62;
    even3 = c04p + b23 + b63;
    odd0  = b10 + b30 + b50 + b70;
    odd1  = b11 + b31 + b51 + b71;
    odd2  = b12 + b32 + b52 + b72;
    odd3  = b13 + b33 + b53 + b73;

    (*y)[0] = even0 + odd0;
    (*y)[1] = even1 + odd1;
    (*y)[2] = even2 + odd2;
    (*y)[3] = even3 + odd3;
    (*y)[4] = even3 - odd3;
    (*y)[5] = even2 - odd2;
    (*y)[6] = even1 - odd1;
    (*y)[7] = even0 - odd0;
}

void dumpi(const imat8 *d)
{
	int i, j;
	for(i = 0; i < 8; i++) {
		for(j = 0; j < 8; j++) {
			xil_printf("%3d, ", (*d)[i][j]);
		}
		xil_printf("\n\r");
	}
	xil_printf("\n\r\n\r");
}

void dump(const mat8 *d)
{
	int i,j;
	for(i = 0; i < 8; i++) {
		for(j = 0; j < 8; j++) {
			xil_printf("%5.3f, ", (*d)[i][j]);
		}
		xil_printf("\n\r");
	}
	xil_printf("\n\r\n\r");
}
