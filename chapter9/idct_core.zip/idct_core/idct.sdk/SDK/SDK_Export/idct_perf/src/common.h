#ifndef __COMMON_H__
#define __COMMON_H__

typedef double vec8[8];
typedef vec8 mat8[8];

typedef int ivec8[8];
typedef ivec8 imat8[8];

void idct_init();
void idct(const mat8 *in, mat8 *out);

void dumpi(const imat8 *d);
void dump(const mat8 *d);
#endif
