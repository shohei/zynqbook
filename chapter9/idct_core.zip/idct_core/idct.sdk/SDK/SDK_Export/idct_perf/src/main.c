#include "platform.h"
#include "xil_io.h"
#include "xtime_l.h"
#include "idct_ip.h"
#include "common.h"


static const u8 __attribute__((aligned (128))) in_buf[IN_BUF_SIZE] = {
		0xf7, 0xff, 0x04, 0x00, 0x00, 0x00, 0xe1, 0xff,
		0xda, 0xff, 0xa2, 0xff, 0x1e, 0x00, 0xa2, 0x00,

		0x0b, 0x00, 0xfe, 0xff, 0xf5, 0xff, 0x11, 0x00, 
		0xad, 0xff, 0xc4, 0xff, 0x6c, 0x00, 0x28, 0x00,

		0x07, 0x00, 0x0c, 0x00, 0x0c, 0x00, 0xfb, 0xff, 
		0xfb, 0xff, 0x0c, 0x00, 0x0a, 0x00, 0x14, 0x00,

		0xf0, 0xff, 0x06, 0x00, 0x00, 0x00, 0xf4, 0xff, 
		0xea, 0xff, 0xd5, 0xff, 0x20, 0x00, 0x48, 0x00,

		0x15, 0x00, 0xee, 0xff, 0x1c, 0x00, 0x0e, 0x00, 
		0xf3, 0xff, 0xe1, 0xff, 0x1b, 0x00, 0x1e, 0x00,

		0x00, 0x00, 0xf4, 0xff, 0x0c, 0x00, 0xfb, 0xff, 
		0x0f, 0x00, 0x06, 0x00, 0xf1, 0xff, 0x0c, 0x00,

		0x05, 0x00, 0x07, 0x00, 0x08, 0x00, 0x0b, 0x00, 
		0xff, 0xff, 0xfd, 0xff, 0x12, 0x00, 0xed, 0xff,

		0x0a, 0x00, 0x0c, 0x00, 0x02, 0x00, 0xfa, 0xff, 
		0x03, 0x00, 0x07, 0x00, 0xff, 0xff, 0xf5, 0xff
};
static u8 __attribute__((aligned (128))) out_buf[OUT_BUF_SIZE];


void DCT_TEST_MasterRecvBytes(u32 BaseAddress, u32 SrcAddress, int Size)
{
	int LsbSize;
	int MsbSize;
	LsbSize = (u16)Size;
	MsbSize = (u8)(Size >> 16);

	Xil_Out8(BaseAddress+MST_CNTL_REG_OFFSET, MST_BRRD);
	Xil_Out32(BaseAddress+MST_ADDR_REG_OFFSET, SrcAddress);
	Xil_Out16(BaseAddress+LSB_MST_LEN_REG_OFFSET, LsbSize);
	Xil_Out8(BaseAddress+MSB_MST_LEN_REG_OFFSET, MsbSize);
	Xil_Out8(BaseAddress+MST_GO_PORT_OFFSET, MST_START);
}

void DCT_TEST_MasterSendBytes(u32 BaseAddress, u32 DstAddress, int Size)
{
	int LsbSize;
	int MsbSize;
	LsbSize = (u16)Size;
	MsbSize = (u8)(Size >> 16);
	Xil_Out8(BaseAddress+MST_CNTL_REG_OFFSET, MST_BRWR);
	Xil_Out32(BaseAddress+MST_ADDR_REG_OFFSET, DstAddress);
	Xil_Out16(BaseAddress+LSB_MST_LEN_REG_OFFSET, LsbSize);
	Xil_Out8(BaseAddress+MSB_MST_LEN_REG_OFFSET, MsbSize);
	Xil_Out8(BaseAddress+MST_GO_PORT_OFFSET, MST_START);
}

void idct_test()
{
	const u32 baseaddr = XPAR_IDCT_0_BASEADDR;
	volatile const u8 *in = in_buf;
	volatile u8 *out = out_buf;

    DCT_TEST_MasterRecvBytes(baseaddr, (u32)in, IN_BUF_SIZE);
    while (!IS_TRANSFER_DONE(baseaddr)) {}

    while (!IS_DCT_DONE(baseaddr)) {}

    DCT_TEST_MasterSendBytes(baseaddr, (u32)out, OUT_BUF_SIZE);
    while (!IS_TRANSFER_DONE(baseaddr)) {}
}

void user_init()
{
	u32 flags = Xil_In32(XPS_SCU_PERIPH_BASE);
	xil_printf("XPS_SCU_PERIPH_BASE %08x\n\r", flags);
}

#define MCU_COUNT ((1920/8)*(1080/8)*3)

void sw_vs_hw()
{
	int i;
	XTime start, end;
	const u32 *s = (u32*)&start;
	const u32 *e = (u32*)&end;

	//-----------------------------
	xil_printf("Software\n\r");
	XTime_GetTime(&start);
	mat8 in, out;
	for (i = 0; i < MCU_COUNT; i++) {
		idct((const mat8*)&in, &out);
	}
	XTime_GetTime(&end);
	
	xil_printf("elapsed: %d %d\n\r", e[1]-s[1], e[0]-s[0]);

	//-----------------------------
	xil_printf("\n\r");
	xil_printf("Hardware\n\r");
	XTime_GetTime(&start);
    for (i = 0; i < MCU_COUNT; i++) {
		idct_test();
	}
	XTime_GetTime(&end);

	xil_printf("elapsed: %d %d\n\r", e[1]-s[1], e[0]-s[0]);
}


int main()
{
	init_platform();
	user_init();
	idct_init();

	sw_vs_hw();

	cleanup_platform();
    return 0;
}

